//
//  InformacionPersonal.swift
//  act1
//
//  Created by Alumno on 20/01/26.
//

import Foundation

struct InformacionPersonal {
    var nombre: String
    var edad: Int
    var colorFavorito: String
}

func imprimirInformacionPersonal(_ info: InformacionPersonal) {
    print("Nombre: \(info.nombre)")
    print("Edad: \(info.edad)")
    print("Color favorito: \(info.colorFavorito)")
}
