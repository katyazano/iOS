import SwiftUI

struct ContentView: View {

    let miInformacion = InformacionPersonal(
        nombre: "katheryn",
        edad: 20,
        colorFavorito: "blanco"
    )

    var body: some View {
        Text("Revisa la consola")
            .padding()
            .onAppear {
                imprimirInformacionPersonal(miInformacion)
            }
    }
}

#Preview {
    ContentView()
}
